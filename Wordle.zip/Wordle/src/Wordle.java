import java.util.Locale;
import java.util.Scanner;

public class Wordle {

    public static void main(String[] args) {
        System.out.println("How long should the wordle be?");
        int lengthInput = getIntInput(1, 10);
        Wordle w = new Wordle(lengthInput);
        char[] wordInput = w.getInput(lengthInput);
        int[] score = w.scoreWord(wordInput, w.correctWord);
        for (int i: score){
            System.out.print(i + ", ");
        }
    }

    char[] correctWord;
    int wordleLength;

    public Wordle(int wordleLength){
        this.wordleLength = wordleLength;
        //Until I get the data set working the correctWord will be user inputted
        System.out.println("What should the correctWord be?");
        correctWord = getInput(wordleLength);
    }

    public int[] scoreWord(char[] word, char[] correctWord){
        int[] score = new int[word.length];
        for (int i: score){i=0;}

        char[] mutableCorrectWord = correctWord.clone();

        for (int i = 0; i < word.length; i++){
            if (word[i] == mutableCorrectWord[i]){
                score[i] = 2;
                word[i] = '*';
                mutableCorrectWord[i] = '*';
            }
        }

        for (char ch: mutableCorrectWord){
            if (ch != '*'){
                int firstIndex = getFirstIndex(word, ch);
                if (firstIndex != -1){
                    score[firstIndex] = 1;
                }
            }
        }
        return score;
    }

    public int getFirstIndex(char[] word, char target){
        for (int i = 0; i < word.length; i++){
            if (word[i] == target){
                return i;
            }
        }
        return -1;
    }

    public char[] getInput(int inputLength){
        Scanner scanner = new Scanner(System.in);
        System.out.println("Input a " + inputLength + " letter word");
        while (true){
            String input = scanner.nextLine();
            if (input.length() == inputLength){
                return input.toLowerCase().toCharArray();
            } else{
                System.out.println("Your input needs to be " + inputLength + " letters long");
            }
        }
    }

    public static int getIntInput(int min, int max){
        Scanner scanner = new Scanner(System.in);
        while (true){
            String input = scanner.nextLine();
            int intInput;
            try{
                intInput = Integer.parseInt(input);
            } catch (NumberFormatException nfe) {
                System.out.println("Please give an integer");
                continue;
            }
            if (intInput <= max && intInput >= min){
                return intInput;
            } else {
                System.out.println("Please give an integer between " + min + " and " + max);
            }
        }
    }
}
