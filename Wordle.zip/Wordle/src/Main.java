public class Main {
    public static void main(String[] args){
    //LinkedList
        double average = 0;
    int lengthInput = 2;
    double wordCount = 39;
    double startTime = System.currentTimeMillis();
        for(int i = 0 ; i < wordCount; i++){
        LinkedListSolve r = new LinkedListSolve(lengthInput, i);
        }
    double endTime = System.currentTimeMillis();
    average = LinkedListSolve.total/wordCount;
    double time =  (endTime - startTime);
    double avgTime =  (time/wordCount);
        System.out.println("Average Guesses: " + average);
        System.out.println("Solved: "+ LinkedListSolve.solved);
        System.out.println("Time: " + time + " Milliseconds");
        System.out.println("Average solve time: " + avgTime);

}}
