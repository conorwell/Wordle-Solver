import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class EntropyMaximizerTest {

    @Test
    void doesWordFitScore() {
        EntropyMaximizer e = new EntropyMaximizer(5);
        char[] scoredWord = "weary".toCharArray();
        int[] score = new int[]{0,2,2,1,0};
        char[] testWord = "reach".toCharArray();
        assertTrue(e.doesWordFitScore(testWord, score, scoredWord));
        testWord = "yeach".toCharArray();
        assertFalse(e.doesWordFitScore(testWord, score, scoredWord));
        testWord = "zearh".toCharArray();
        assertFalse(e.doesWordFitScore(testWord, score, scoredWord));
        testWord = "erach".toCharArray();
        assertFalse(e.doesWordFitScore(testWord, score, scoredWord));
    }
}